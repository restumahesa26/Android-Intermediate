package com.example.storyapp.helper

class Constanta {

    companion object {
        val NAME = "NAME"
        val USER_ID = "USER_ID"
        val TOKEN = "TOKEN"
    }

}